# encryptionDriver
This is a little rot47 encryption project for a class.

The program works on ubuntu 12.04

To use just run:
  $ sudo su
  $ ./install.sh
  
That will load the driver into memory.  Then to see how to use the driver look at rot47.c for an example!  Happy Coding
